package juego;

import java.util.Random;

/**
 * Clase donde generamos los enemigos con unas caracteristicas especificas
 * 
 * @author roberto
 * @version 0.1
 * @since 0.2 Alpha
 */
public class Enemigo extends Thread {

	static String enemigo = Jugador.ANSI_RED + "☻" + Jugador.ANSI_RESET;

	public static int enemigosRestantes = 0;
	private int columna;
	private int fila;
	private boolean enemigoVivo;

	Random random = new Random();
	Tablero tablero;
	Torre[] torre;
	Jugador jugador;

	/**
	 * Constructor con parametros en el cual realizaremos el posicionamiento del
	 * enemigo en el tablero
	 * 
	 * @param torre   Array de objetos torre que guardamos de manera global en la
	 *                clase
	 * @param tablero Objeto tablero que guardamos de manera global en la clase
	 * @param jugador Objeto jugador que guardamos de manera global en la clase
	 * 
	 */
	Enemigo(Torre[] torre, Tablero tablero, Jugador jugador) {

		this.torre = torre;
		this.tablero = tablero;
		this.jugador = jugador;
		this.enemigoVivo = true;

		while (!posicionarEnemigo(torre)) {

			posicionarEnemigo(torre);

		}

	}

	/**
	 * Metodo para posicionar el Enemigo en el tablero, por cada torre que exista
	 * vamos a comprobar si se encuentra en la misma fila que el enemigo, la cual se
	 * generar de manera random, si es que si vamos a devolver True y poner que
	 * nuestra columna sera la 49 y si es que no volvemos a ejecutar este metodo
	 * hasta posicionar el enemigo
	 * 
	 * @param torre Array de objetos Torre que necesitamos para recorrer las torres
	 *              una a una y comprobar sus filas
	 * @return Devolvemos un booleano el cual si es true se para la ejecuccion
	 *         anterior del while
	 */
	private boolean posicionarEnemigo(Torre[] torre) {

		boolean PosicionCorrecta;
		int j = random.nextInt(0, Torre.contador);

		this.setFila(random.nextInt(0, 5));

		if (torre[j].getFila() == getFila()) {

			PosicionCorrecta = true;
			this.setColumna(49);

		} else {
			PosicionCorrecta = false;
		}
		return PosicionCorrecta;
	}

	// Inicio del hilo y lo que tiene que realizar
	@Override
	public void run() {

		avanza(tablero, torre, jugador);
		interrupt();
	}

	/**
	 * Este metodo hara que el enemigo avance una posicion cada vez que no impacte
	 * contra nada, si impacta contra algo, este enemigo desaparece y su hilo se
	 * interrumpe, si el enemigo llega hasta la coordenada y, 0 entonces este para
	 * su ejecuccion, resta una vida al usuario y para su ejecuccion
	 * 
	 * @param tablero Objeto que necesitamos para saber si su hilo sigue activo y
	 *                tambien para hacer uso de el en otros metodos, pasandolo como
	 *                argumento
	 * @param torre   Array de objetos necesario para otros metodos incluidos en
	 *                este metodo
	 * @param jugador sirve para acceder a las vidas del jugador y restarle 1 cada
	 *                vez que un enemigo llega a la columna 0
	 */
	void avanza(Tablero tablero, Torre[] torre, Jugador jugador) {

		if (tablero.isAlive()) {

			for (int i = getColumna(); i >= 0; i--) {

				setColumna(i);

				tablero.actualizaTablero(getFila(), getColumna(), enemigo);

				if (comprobarImpacto(tablero, torre)) {

					break;
				}

				if (getColumna() == 0) {

					tablero.actualizaTablero(getFila(), getColumna(), enemigo);
					jugador.setVidas(jugador.getVidas() - 1);
					Enemigo.enemigosRestantes--;
					break;

				}

			}
		} else {
			interrupt();
		}

	}

	/**
	 * Con este metodo comprobamos si el enemigo a impactado con una Torre, si es
	 * que si devolvemos true al metodo anterior, en cambio vamos a dormir el hilo
	 * 150 milisegundos antes de volver a avanzarlo
	 * 
	 * @param tablero objeto necesario para poder actualizar el tablero
	 * @param torre   Array de objetos que pasamos como argumento al metodo
	 *                impactoTorre
	 * @return devuelve un booleano dependiendo si hemos chocado o no contra una
	 *         torre
	 */
	private boolean comprobarImpacto(Tablero tablero, Torre[] torre) {

		if (impactoTorre(tablero, torre, getColumna())) {

			return true;

		} else {

			try {

				Thread.sleep(150);

			} catch (Exception e) {
				interrupt();
			}

			tablero.actualizaTablero(getFila(), getColumna(), " ");

			return false;
		}

	}

	/**
	 * Por cada torre existente vamos a comprobar si sus coordenadas coinciden con
	 * las del enemigo, si es asi hemos impactado con una torre y el enemigo muere
	 * Dependiendo de la torre que hemos impactado, si es de nivel 1 esa torre acaba
	 * siendo destruida, si es de nivel 2 esa torre se convierte a una de nivel 1 y
	 * lo mismo sucede si es una torre de nivel 3 que acabara siendo una torre de
	 * nivel 2
	 * 
	 * @param tablero Objeto tablero, util para acceder a sus metodos para
	 *                actualizar el tablero cuando lo necesitemos
	 * @param torre   Array de objetos Torre necesarios para ir torre por torre a
	 *                comprobar su fila y columna
	 * @param columna entero que sera una iteracion del bucle for antes visto
	 * @return un valor booleano para comprobar si hemos o no impactado con una
	 *         torre
	 */
	private boolean impactoTorre(Tablero tablero, Torre[] torre, int columna) {
		boolean impacto = false;

		for (int j = 0; j < Torre.contador; j++) {
			if (torre[j].getFila() == getFila() && torre[j].getColumna() == columna && !torre[j].isDestruida()) {

				switch (torre[j].getNivel()) {
				case Torre.NIVEL1:

					/*
					 * La torre actual se destruye y el enemig al impactar con ella tambien.
					 */

					Torre.torresVivas--;
					Enemigo.enemigosRestantes--;
					torre[j].setDestruida(true);
					torre[j].setPuedeDisparar(false);
					torre[j].setNivel("DESTRUIDA");
					torre[j].setPrecio(2000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), " ");

					break;

				case Torre.NIVEL2:

					Enemigo.enemigosRestantes--;
					torre[j].setNivel(Torre.NIVEL1);
					torre[j].setPrecio(10000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), Torre.NIVEL1);

					break;

				case Torre.NIVEL3:

					Enemigo.enemigosRestantes--;
					torre[j].setNivel(Torre.NIVEL2);
					torre[j].setPrecio(20000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), Torre.NIVEL2);

					break;

				default:

					impacto = false;

					break;
				}

				impacto = true;

				break;

			}

		}
		return impacto;
	}

	public static int getEnemigosRestantes() {
		return enemigosRestantes;
	}

	public static void setEnemigosRestantes(int enemigosRestantes) {
		Enemigo.enemigosRestantes = enemigosRestantes;
	}

	public boolean isEnemigoVivo() {
		return enemigoVivo;
	}

	public void setEnemigoVivo(boolean enemigoVivo) {
		this.enemigoVivo = enemigoVivo;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public int getFila() {
		return fila;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

}
