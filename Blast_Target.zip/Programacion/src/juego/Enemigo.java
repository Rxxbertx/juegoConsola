package juego;

import java.util.Random;

/**
 * 
 * @author roberto
 *
 */
public class Enemigo extends Thread {

	static String enemigo = Jugador.ANSI_RED + "☻" + Jugador.ANSI_RESET;

	public static int enemigosRestantes = 0;
	private int columna;
	private int fila;
	private boolean enemigoVivo;

	public static int getEnemigosRestantes() {
		return enemigosRestantes;
	}

	public static void setEnemigosRestantes(int enemigosRestantes) {
		Enemigo.enemigosRestantes = enemigosRestantes;
	}

	public boolean isEnemigoVivo() {
		return enemigoVivo;
	}

	public void setEnemigoVivo(boolean enemigoVivo) {
		this.enemigoVivo = enemigoVivo;
	}

	Random random = new Random();
	Tablero tablero;
	Torre[] torre;
	Jugador jugador;

	/**
	 * 
	 * @param torre
	 * @param tablero
	 * @param jugador
	 * @param enemigosGenerar
	 */
	Enemigo(Torre[] torre, Tablero tablero, Jugador jugador, int enemigosGenerar) {

		this.torre = torre;
		this.tablero = tablero;
		this.jugador = jugador;
		this.enemigoVivo = true;

		while (!posicionarEnemigo(torre)) {

			posicionarEnemigo(torre);

		}

	}

	/**
	 * 
	 * @param torre
	 * @return
	 */
	private boolean posicionarEnemigo(Torre[] torre) {

		boolean PosicionCorrecta;
		int j = random.nextInt(0, Torre.contador);

		this.setFila(random.nextInt(0, 5));

		if (torre[j].getFila() == getFila()) {

			PosicionCorrecta = true;
			this.setColumna(49);

		} else {
			PosicionCorrecta = false;
		}
		return PosicionCorrecta;
	}

	@Override
	public void run() {

		avanza(tablero, torre, jugador);
		interrupt();
	}

	/**
	 * 
	 * @param tablero
	 * @param torre
	 * @param jugador
	 */
	void avanza(Tablero tablero, Torre[] torre, Jugador jugador) {

		if (tablero.isAlive()) {

			for (int i = getColumna(); i >= 0; i--) {

				setColumna(i);

				tablero.actualizaTablero(getFila(), getColumna(), enemigo);

				if (comprobarImpacto(tablero, torre, jugador)) {

					break;
				}

				if (getColumna() == 0) {

					tablero.actualizaTablero(getFila(), getColumna(), enemigo);
					jugador.setVidas(jugador.getVidas() - 1);
					Enemigo.enemigosRestantes--;
					break;

				}

			}
		} else {
			interrupt();
		}

	}

	/**
	 * 
	 * @param tablero
	 * @param torre
	 * @param jugador
	 * @return
	 */
	private boolean comprobarImpacto(Tablero tablero, Torre[] torre, Jugador jugador) {

		if (impactoTorre(tablero, torre, getColumna())) {

			return true;

		} else {

			try {

				Thread.sleep(150);

			} catch (Exception e) {
				interrupt();
			}

			tablero.actualizaTablero(getFila(), getColumna(), " ");

			return false;
		}

	}

	/**
	 * 
	 * @param tablero
	 * @param torre
	 * @param columna
	 * @return
	 */
	private boolean impactoTorre(Tablero tablero, Torre[] torre, int columna) {
		boolean impacto = false;

		for (int j = 0; j < Torre.contador; j++) {
			if (torre[j].getFila() == getFila() && torre[j].getColumna() == columna && !torre[j].isDestruida()) {

				switch (torre[j].getNivel()) {
				case Torre.NIVEL1:

					Torre.torresVivas--;
					Enemigo.enemigosRestantes--;
					torre[j].setDestruida(true);
					torre[j].setPuedeDisparar(false);
					torre[j].setNivel("DESTRUIDA");
					torre[j].setPrecio(2000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), " ");

					break;

				case Torre.NIVEL2:

					Enemigo.enemigosRestantes--;
					torre[j].setNivel(Torre.NIVEL1);
					torre[j].setPrecio(10000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), Torre.NIVEL1);

					break;

				case Torre.NIVEL3:

					Enemigo.enemigosRestantes--;
					torre[j].setNivel(Torre.NIVEL2);
					torre[j].setPrecio(20000);
					tablero.actualizaTablero(torre[j].getFila(), torre[j].getColumna(), Torre.NIVEL2);

					break;

				default:

					impacto = false;

					break;
				}

				impacto = true;

				break;

			}

		}
		return impacto;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public int getFila() {
		return fila;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

}
