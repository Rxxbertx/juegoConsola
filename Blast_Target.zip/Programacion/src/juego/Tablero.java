package juego;

/**
 * Clase en la cual se observa la accion del juego, el tablero es creado a
 * partir de una array bidimensional rellenado con espacios en blanco los cual
 * seran sobrescritos por los enemigos, torres, proyectiles.
 * 
 * @author roberto
 * @version 1.0
 * @since 0.1 Alpha
 */

public class Tablero extends Thread {

	private int columna;
	private int fila;
	Jugador jugador;

	String tablero[][];
	private Torre[] torre;

	/**
	 * Constructor con parametros el cual crea el tablero con espacios en blanco y
	 * con las torres creadas y no destruidas
	 * 
	 * @param fila    entero el cual determinara las filas totales del array
	 *                bidimesional (tablero)
	 * @param columna entero el cual determinara las columans totales del array
	 *                bidimesional (tablero)
	 * @param jugador Objeto el cual nos hacer falta para otros metodos de esta
	 *                clase
	 * @param torre   Array de objetos torre el cual nos sirve para saber que torre
	 *                mostrar en el tablero y cual no
	 */
	public Tablero(int fila, int columna, Jugador jugador, Torre[] torre) {

		this.columna = columna;
		this.fila = fila;
		this.jugador = jugador;
		this.torre = torre;
		tablero = new String[fila][columna];
		// columna es de izquierda a derecha fila es de arriba a abajo

		for (int i = 0; i < fila; i++)
			for (int j = 0; j < columna; j++)
				tablero[i][j] = " ";

		for (int i = 0; i < Torre.contador; i++) {
			if (torre[i].isDestruida()) {

			} else {
				actualizaTablero(torre[i].getFila(), torre[i].getColumna(), torre[i].getNivel());
			}
		}
	}

	@Override
	public void run() {

		/**
		 * Esta es la ejecucion del hilo del tablero, mientras se ejecute vamos a dormir
		 * el hilo 150ms para despues mostar el tablero con las torres y las
		 * estadisticas del jugador. Hasta que el las vidas del jugador, las torres o
		 * los enemigosRestantes lleguen a 0, cuando lleguen a 0 la ejecuccion para y el
		 * hilo tambien
		 */

		boolean ejecucion = true;
		while (ejecucion) {

			try {

				Thread.sleep(150);
				System.out.print("\n\n");
				Jugador.stats(jugador);
				imprimeTablero(torre);
				System.out.print("\n\n");

			} catch (InterruptedException e) {

			}

			if (jugador.getVidas() == 0 || Torre.torresVivas == 0 || Enemigo.enemigosRestantes == 0) {
				ejecucion = false;

			}

		}

	}

	/**
	 * Este metodo sirve para mostrar el tablero visualmente con las torres creadas
	 * y con los enemigos, proyectiles, durante la ejecucion
	 * 
	 * @param torre Array de objetos torre el cual nos sirve para saber que torre
	 *              mostrar en el tablero y cual no
	 */
	void imprimeTablero(Torre[] torre) {

		for (int i = 0; i < Torre.contador; i++) {

			if (torre[i].isDestruida()) {
				actualizaTablero(torre[i].getFila(), torre[i].getColumna(), " ");
			} else {
				actualizaTablero(torre[i].getFila(), torre[i].getColumna(), torre[i].getNivel());
			}
		}
		System.out.print(Jugador.ANSI_CYAN + "╔");

		for (int i = 0; i < columna; i++) {
			System.out.print("═");
		}
		System.out.print("╗" + Jugador.ANSI_RESET);
		System.out.println();

		// ahora imprimimos todas las filas y columnas del tablero
		// este bucle for controla la impresión de las líneas
		for (int i = 0; i < fila; i++) {

			System.out.print(Jugador.ANSI_CYAN + "║" + Jugador.ANSI_RESET);

			for (int j = 0; j < columna; j++) {
				System.out.print(tablero[i][j]);

			}
			System.out.print(Jugador.ANSI_CYAN + "║" + Jugador.ANSI_RESET);
			System.out.println();

		}
		System.out.print(Jugador.ANSI_CYAN + "╚");
		for (int i = 0; i < columna; i++) {
			System.out.print("═");
		}
		System.out.println("╝" + Jugador.ANSI_RESET);

	}

	/**
	 * Metodo para actualizar el tablero en ciertas coordenadas con una figura, la
	 * cual bien sera una torre, un enemigo y un proyectil
	 * 
	 * @param fila    entero el cual determinara las fila del array bidimesional
	 *                (tablero)
	 * @param columna entero el cual determinara las columna del array bidimesional
	 *                (tablero)
	 * @param figura  String el cual se colocara en esas coordenadas una figura
	 *                (enemigo,proyectil..) en el (tablero)
	 */
	void actualizaTablero(int fila, int columna, String figura) {
		tablero[fila][columna] = figura;
	}

}
