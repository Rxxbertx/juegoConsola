package juego;

import java.util.Random;

/**
 * Esta es una clase la cual determina atributos y metodos del jugador, como por
 * ejemplo el dinero y las vidas
 * 
 * @author roberto
 * @version 1.0 stable
 * @since 0.1 Alpha
 */
public class Jugador {

	/*
	 * Son codigos de color que se muestran bonitos en los SYSO
	 * 
	 */

	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	public static final String ANSI_RESET = "\u001B[0m";
	public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
	public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
	public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
	public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
	public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
	public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
	public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
	public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";

	private int dinero;
	private int vidas;

	/**
	 * Constructor por defecto
	 */

	Jugador() {

		dinero = 500000;
		vidas = 3;

	}

	public int getDinero() {
		return dinero;
	}

	public void setDinero(int dinero) {
		this.dinero += dinero;
	}

	public int getOleada() {
		return Oleada.contadorOleadas;

	}

	public int getTorres() {
		return Torre.torresVivas;
	}

	public int getVidas() {
		return vidas;
	}

	public void setVidas(int vidas) {
		this.vidas = vidas;
	}

	/**
	 * Metodo statico de la clase jugador el cual muestra las estadisticas del
	 * jugador.
	 * 
	 * @param player es el objeto jugador
	 */
	public static void stats(Jugador player) {
		System.out.print("\n\n\n\n\n" + ANSI_CYAN_BACKGROUND + ANSI_RED + "PUNTOS: " + ANSI_BLACK + player.getDinero()
				+ ANSI_RESET);
		System.out
				.print(ANSI_CYAN_BACKGROUND + ANSI_RED + "    OLEADA: " + ANSI_BLACK + player.getOleada() + ANSI_RESET);
		System.out
				.print(ANSI_CYAN_BACKGROUND + ANSI_RED + "    TORRES: " + ANSI_BLACK + player.getTorres() + ANSI_RESET);
		System.out.print(ANSI_CYAN_BACKGROUND + ANSI_RED + "    VIDAS: " + ANSI_RED + player.getVidas() + ANSI_RESET);
		System.out.println();
	}

	/**
	 * Metodo statico para colorear la bienvenida caracter a caracter, su funcion es
	 * basicamente un random entre 0 y 1 y dependiendo del numero escoge un color
	 * 
	 * @return Un string
	 */
	public static String colorAleatorio() {
		String color = null;

		Random azar = new Random();
		int num = azar.nextInt(0, 2);

		switch (num) {
		case 0:

			color = ANSI_GREEN;
			break;
		case 1:

			color = ANSI_YELLOW;
			break;

		}
		return color;

	}

}
