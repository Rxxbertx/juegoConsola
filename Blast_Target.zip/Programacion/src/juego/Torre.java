package juego;

import java.util.Scanner;

/**
 * 
 * @author roberto
 *
 */

public class Torre extends Thread {

	static final String NIVEL1 = Jugador.ANSI_YELLOW + "▒" + Jugador.ANSI_RESET;
	static final String NIVEL2 = Jugador.ANSI_GREEN + "▓" + Jugador.ANSI_RESET;
	static final String NIVEL3 = Jugador.ANSI_BLUE + "█" + Jugador.ANSI_RESET;
	private String nivel = "";

	Tablero tablero;
	Enemigo[] enemigo;
	Jugador jugador;

	private static final int PRECIO_COMPRAR_TORRE = 5000;
	private static final int PRECIO_ACTUALIZAR_TORRE_NIVEL2 = 10000;
	private static final int PRECIO_ACTUALIZAR_TORRE_NIVEL3 = 20000;
	private static final int PRECIO_RECONSTRUIR_TORRE = 2000;
	private String precio;

	static int contador = 0;
	static int torresVivas = 0;

	private int fila;
	private int columna;

	private boolean puedeDisparar = true;
	private boolean destruida = false;

	private int id = contador;
	private int enemigosGenerar;

	/**
	 * 
	 */
	Torre() {

		this.id = contador;
		this.nivel = NIVEL1;
		this.setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL2);

	}

	/**
	 * 
	 * @param torre
	 * @param player
	 * @param t1
	 */
	public static void comprarTorre(Torre[] torre, Jugador player, Tablero t1) {
		torre[Torre.contador] = new Torre();
		torre[Torre.contador].colocarTorre(t1, player, torre);
	}

	/**
	 * 
	 * @param torre
	 * @param tablero
	 * @param jugador
	 * @param sc
	 */
	protected static void seleccionarTorreActualizar(Torre[] torre, Tablero tablero, Jugador jugador, Scanner sc) {

		if (Torre.contador == 0) {
			System.out.println("NO TIENES NINGUNA TORRE " + Jugador.ANSI_RED + "COMPRA" + Jugador.ANSI_RESET);
			suspenderEjecucion(1000);

		} else if (jugador.getDinero() <= 2000) {
			sinPuntosSuficientes(jugador);
		} else {
			System.out.println("Que torre quieres actualizar");

			for (int i = 0; i < Torre.contador; i++) {

				System.out.println("➖➖➖➖➖➖➖➖➖➖");
				System.out.println("NIVEL: " + torre[i].getNivel());
				System.out.print(Jugador.ANSI_RED + "COLUMNA" + Jugador.ANSI_RESET + ": " + torre[i].getColumna());
				System.out.println(Jugador.ANSI_RED + "\tFILA" + Jugador.ANSI_RESET + ": " + torre[i].getFila());
				System.out.println("TORRE: " + torre[i].getId());
				System.out.println("PRECIO: " + Jugador.ANSI_RED + torre[i].getPrecio() + Jugador.ANSI_RESET);
				System.out.println("➖➖➖➖➖➖➖➖➖➖");
			}

			int resp = sc.nextInt();

			if (resp >= Torre.contador || resp < 0) {
				System.err.println("Error, has seleccionado una torre inexistente");

			} else {
				torre[resp].actualizarTorre(tablero, jugador);
			}

		}
	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 */
	void actualizarTorre(Tablero tablero, Jugador jugador) {

		switch (nivel) {

		case (NIVEL1):

			if (jugador.getDinero() < 10000) {
				sinPuntosSuficientes(jugador);
			} else {
				this.nivel = NIVEL2;
				setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL3);
				tablero.actualizaTablero(fila, columna, nivel);
				jugador.setDinero(-10000);
			}

			break;

		case (NIVEL2):

			if (jugador.getDinero() < 20000) {
				sinPuntosSuficientes(jugador);
			} else {
				this.nivel = NIVEL3;
				this.precio = "NIVEL MAXIMO ALCANZADO";
				tablero.actualizaTablero(fila, columna, nivel);
				jugador.setDinero(-20000);

			}
			break;

		case (NIVEL3):

			System.err.println("NIVEL MAXIMO ALCANZADO");
			suspenderEjecucion(1000);

			break;

		default:
			if (jugador.getDinero() < 2000) {
				System.err.println("NO DISPONES DE SUFICIENTE DINERO");
				suspenderEjecucion(1000);
			} else {
				jugador.setDinero(-2000);
				this.nivel = NIVEL1;
				this.destruida = false;
				this.puedeDisparar = true;
				setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL2);
				Torre.torresVivas++;
			}
			break;
		}

	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 * @param torre
	 */
	void colocarTorre(Tablero tablero, Jugador jugador, Torre[] torre) {
		int filaTorre;
		int columnaTorre;
		boolean PosicionCorrecta = false;

		Scanner sc = new Scanner(System.in);

		if (jugador.getDinero() >= PRECIO_COMPRAR_TORRE) {

			System.out.println("Dime en que posicion quieres la torre:");

			while (!PosicionCorrecta) {

				System.out.println(
						Jugador.ANSI_RED + "Fila" + Jugador.ANSI_RESET + ": (tiene que ser menos o igual a la fila 4)");
				filaTorre = sc.nextInt();

				if (filaTorre <= 4) {

					this.fila = filaTorre;

					System.out.println(Jugador.ANSI_RED + "Columna" + Jugador.ANSI_RESET
							+ ": (tiene que ser menos o igual a la columna 4)");

					columnaTorre = sc.nextInt();
					if (columnaTorre <= 4) {
						this.columna = columnaTorre;

						if (Torre.contador == 0) {
							PosicionCorrecta = true;
						} else {
							int PosicionNoRepetida = 0;
							for (int i = 0; i < Torre.contador; i++) {

								if (columna == torre[i].getColumna() && fila == torre[i].getFila()) {

									System.err.println("\rError has puesto las coordenadas de una torre existente");
									PosicionNoRepetida++;

								} else {
									if (PosicionNoRepetida == 0) {
										PosicionCorrecta = true;
									}
								}

							}
						}
					}

				}

			}

			jugador.setDinero(-PRECIO_COMPRAR_TORRE);
			contador++;
			torresVivas++;
			tablero.actualizaTablero(fila, columna, nivel);
		} else {
			System.out.println("No dispones de " + Jugador.ANSI_RED + "PUNTOS" + Jugador.ANSI_RESET + " suficientes");
			System.out.println("(comprar una torre cuesta 5000)");
			suspenderEjecucion(1000);
		}

	}

	@Override
	public void run() {

		while (tablero.isAlive()) {

			suspenderEjecucion(1000);
			
			while (!destruida) {

				new Proyectil(tablero, columna, fila, nivel, jugador, enemigo, enemigosGenerar);

			}
			if (destruida || Enemigo.enemigosRestantes == 0) {
				Thread.currentThread().interrupt();

			}
		}
		if (!tablero.isAlive()) {
			Thread.currentThread().interrupt();
		}

	}

	/**
	 * 
	 * @param jugador
	 */
	private static void sinPuntosSuficientes(Jugador jugador) {
		System.out
				.println("NO TIENES PUNTOS SUFICIENTES " + Jugador.ANSI_RED + "INICIA UNA OLEADA" + Jugador.ANSI_RESET);
		suspenderEjecucion(1000);
	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 */
	public void setTableroyJugador(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {
		this.tablero = tablero;
		this.jugador = jugador;
		this.enemigo = enemigo;
		this.enemigosGenerar = enemigosGenerar;

	}

	public String getNivel() {
		return nivel;
	}

	public void setNivel(String nivel) {
		this.nivel = nivel;
	}

	public String getPrecio() {
		return precio;
	}

	/**
	 * 
	 * @param precio
	 */
	public void setPrecio(int precio) {

		String intercambio = String.valueOf(precio);

		this.precio = intercambio;
	}

	public long getId() {
		return id;
	}

	public int getFila() {
		return fila;
	}

	public int getColumna() {
		return columna;
	}

	public boolean isDestruida() {
		return destruida;
	}

	public void setDestruida(boolean noDestruida) {
		this.destruida = noDestruida;
	}

	public static int getContador() {
		return contador;
	}

	public static void setContador(int contador) {
		Torre.contador = contador;
	}

	public boolean isPuedeDisparar() {
		return puedeDisparar;
	}

	public void setPuedeDisparar(boolean puedeDisparar) {
		this.puedeDisparar = puedeDisparar;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 
	 * @param tiempo
	 */
	private static void suspenderEjecucion(int tiempo) {
		try {
			Thread.sleep(tiempo);
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}
	}

}
