package juego;

import java.util.Scanner;

/**
 * Esta clase sirve para instaciar torres y acceder a ciertos metodos estaticos
 * relacionados con la clase
 * 
 * @author roberto
 * @version 7
 * @since 0.2 Alpha
 *
 */

public class Torre extends Thread {

	static final String NIVEL1 = Jugador.ANSI_YELLOW + "▒" + Jugador.ANSI_RESET;
	static final String NIVEL2 = Jugador.ANSI_GREEN + "▓" + Jugador.ANSI_RESET;
	static final String NIVEL3 = Jugador.ANSI_BLUE + "█" + Jugador.ANSI_RESET;
	private String nivel = "";

	Tablero tablero;
	Enemigo[] enemigo;
	Jugador jugador;

	private static final int PRECIO_COMPRAR_TORRE = 5000;
	private static final int PRECIO_ACTUALIZAR_TORRE_NIVEL2 = 10000;
	private static final int PRECIO_ACTUALIZAR_TORRE_NIVEL3 = 20000;
	private static final int PRECIO_RECONSTRUIR_TORRE = 2000;
	private String precio;

	static int contador = 0;
	static int torresVivas = 0;

	private int fila;
	private int columna;

	private boolean puedeDisparar = true;
	private boolean destruida = false;

	private int id = contador;
	private int enemigosGenerar;

	/**
	 * Este es el constructor por defecto al instanciar una torre
	 */
	Torre() {

		this.id = contador;
		this.nivel = NIVEL1;
		this.setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL2);

	}

	/**
	 * Metodo para comprar torre, en base al contador que tenemos inicializado en 0
	 * , justa ese array torre sera una nueva Torre el cual llama al metodo
	 * colocarTorre para colocarla en el tablero.
	 * 
	 * @param torre  Array de objetos torre en el cual añadimos las torres creadas
	 * @param player Objeto que sirve para acceder a los metodos de la clase
	 * @param t1     Objeto tablero el cual sirve para acceder a los metodos de la
	 *               clase
	 */
	public static void comprarTorre(Torre[] torre, Jugador player, Tablero t1) {
		torre[Torre.contador] = new Torre();
		torre[Torre.contador].colocarTorre(t1, player, torre);
	}

	/**
	 * Este metodo estatico sirve para seleccionar una torre en especifico entre
	 * varias para actualizarla y subirla al siguiente nivel
	 * 
	 * @param torre   Array de objetos torre
	 * @param tablero Objeto tablero el cual sirve para acceder a los metodos de la
	 *                clase
	 * @param jugador Objeto que sirve para acceder a los metodos de la clase
	 * @param sc      Objeto scanner
	 */
	protected static void seleccionarTorreActualizar(Torre[] torre, Tablero tablero, Jugador jugador, Scanner sc) {

		if (Torre.contador == 0) {
			System.out.println("NO TIENES NINGUNA TORRE " + Jugador.ANSI_RED + "COMPRA" + Jugador.ANSI_RESET);
			suspenderEjecucion(1000);

		} else if (jugador.getDinero() <= PRECIO_RECONSTRUIR_TORRE) {
			sinPuntosSuficientes();
		} else {
			System.out.println("Que torre quieres actualizar");

			for (int i = 0; i < Torre.contador; i++) {

				System.out.println("➖➖➖➖➖➖➖➖➖➖");
				System.out.println("NIVEL: " + torre[i].getNivel());
				System.out.print(Jugador.ANSI_RED + "COLUMNA" + Jugador.ANSI_RESET + ": " + torre[i].getColumna());
				System.out.println(Jugador.ANSI_RED + "\tFILA" + Jugador.ANSI_RESET + ": " + torre[i].getFila());
				System.out.println("TORRE: " + torre[i].getId());
				System.out.println("PRECIO: " + Jugador.ANSI_RED + torre[i].getPrecio() + Jugador.ANSI_RESET);
				System.out.println("➖➖➖➖➖➖➖➖➖➖");
			}

			int resp = sc.nextInt();

			if (resp >= Torre.contador || resp < 0) {
				System.err.println("Error, has seleccionado una torre inexistente");

			} else {
				torre[resp].actualizarTorre(tablero, jugador);
			}

		}
	}

	/**
	 * Este metodo es en base a la respuesta anterior al metodo estatico, la torre
	 * que el usuario a seleccionado se le aplicara la actualizacion dependiendo si
	 * tiene dinero o dependiendo del nivel de la torre, por ejemplo si queremos
	 * mejorar una torre que ya se encuentra en su nivel maximo , mostarar un error.
	 * Si tenemos una torre destruida, esa torre pasara a ser de nivel 1 nuevamente
	 * 
	 * @param tablero Objeto tablero el cual sirve para acceder a los metodos de la
	 *                clase
	 * @param jugador Objeto que sirve para acceder a los metodos de la clase
	 */
	void actualizarTorre(Tablero tablero, Jugador jugador) {

		switch (nivel) {

		case (NIVEL1):

			if (jugador.getDinero() < PRECIO_ACTUALIZAR_TORRE_NIVEL2) {
				sinPuntosSuficientes();
			} else {
				this.nivel = NIVEL2;
				setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL3);
				tablero.actualizaTablero(fila, columna, nivel);
				jugador.setDinero(-PRECIO_ACTUALIZAR_TORRE_NIVEL2);
			}

			break;

		case (NIVEL2):

			if (jugador.getDinero() < PRECIO_ACTUALIZAR_TORRE_NIVEL3) {
				sinPuntosSuficientes();
			} else {
				this.nivel = NIVEL3;
				this.precio = "NIVEL MAXIMO ALCANZADO";
				tablero.actualizaTablero(fila, columna, nivel);
				jugador.setDinero(-PRECIO_ACTUALIZAR_TORRE_NIVEL3);

			}
			break;

		case (NIVEL3):

			System.err.println("NIVEL MAXIMO ALCANZADO");
			suspenderEjecucion(1000);

			break;

		default:
			if (jugador.getDinero() < PRECIO_RECONSTRUIR_TORRE) {
				sinPuntosSuficientes();
				suspenderEjecucion(1000);
			} else {
				jugador.setDinero(-PRECIO_RECONSTRUIR_TORRE);
				this.nivel = NIVEL1;
				this.destruida = false;
				this.puedeDisparar = true;
				setPrecio(PRECIO_ACTUALIZAR_TORRE_NIVEL2);
				Torre.torresVivas++;
			}
			break;
		}

	}

	/**
	 * Este metodo sirve para colocar la torre y realizar su compra. Si no
	 * disponemos de suficiente dinero nos avisara. Tambien nos informa de los
	 * limites de fila y columna en la cual podemos posiconar nuestra torre. Si
	 * colocamos la torre en una ya existente dara error y nos volvera a pedir las
	 * nuevas coordenadas
	 * 
	 * @param tablero Objeto tablero el cual sirve para acceder a los metodos de la
	 *                clase
	 * @param jugador Objeto que sirve para acceder a los metodos de la clase
	 * @param torre   Array de objetos torre
	 */
	void colocarTorre(Tablero tablero, Jugador jugador, Torre[] torre) {
		int filaTorre;
		int columnaTorre;
		boolean PosicionCorrecta = false;

		Scanner sc = new Scanner(System.in);

		if (jugador.getDinero() >= PRECIO_COMPRAR_TORRE) {

			System.out.println("Dime en que posicion quieres la torre:");

			while (!PosicionCorrecta) {

				System.out.println(
						Jugador.ANSI_RED + "Fila" + Jugador.ANSI_RESET + ": (tiene que ser menos o igual a la fila 4)");
				filaTorre = sc.nextInt();

				if (filaTorre <= 4) {

					this.fila = filaTorre;

					System.out.println(Jugador.ANSI_RED + "Columna" + Jugador.ANSI_RESET
							+ ": (tiene que ser menos o igual a la columna 4)");

					columnaTorre = sc.nextInt();
					if (columnaTorre <= 4) {
						this.columna = columnaTorre;

						if (Torre.contador == 0) {
							PosicionCorrecta = true;
						} else {
							int PosicionNoRepetida = 0;
							for (int i = 0; i < Torre.contador; i++) {

								if (columna == torre[i].getColumna() && fila == torre[i].getFila()) {

									System.err.println("\rError has puesto las coordenadas de una torre existente");
									PosicionNoRepetida++;

								} else {
									if (PosicionNoRepetida == 0) {
										PosicionCorrecta = true;
									}
								}

							}
						}
					}

				}

			}

			jugador.setDinero(-PRECIO_COMPRAR_TORRE);
			contador++;
			torresVivas++;
			tablero.actualizaTablero(fila, columna, nivel);
		} else {

			System.out.println("(comprar una torre cuesta 5000)");
			sinPuntosSuficientes();

		}

	}

	@Override
	public void run() {

		/**
		 * Si el proceso del tablero sigue ejecutandose entonces mientras la torre no
		 * este destruida disapara proyectiles y entre proyectil y proyectil tendremos
		 * 200ms de pausa
		 */

		while (tablero.isAlive()) {

			while (!destruida) {

				
				new Proyectil(tablero, columna, fila, nivel, jugador, enemigo, enemigosGenerar);
				suspenderEjecucion(1000);

			}

			/**
			 * Si despues de disparar nos encontramos con que la torre esta destruida o bien
			 * los enemigos Restantes son 0 entonces interrumpimos el hilo de la torre y ya
			 * no disparamos mas
			 */

			if (destruida || Enemigo.enemigosRestantes == 0) {
				Thread.currentThread().interrupt();

			}
		}
		if (!tablero.isAlive()) {
			Thread.currentThread().interrupt();
		}

	}

	/**
	 * Este metodo sirve solo para mostrar un mensaje al usuario cuando intenta
	 * actualizar una torre y no dispone de puntos suficientes
	 */
	private static void sinPuntosSuficientes() {
		System.out
				.println("NO TIENES PUNTOS SUFICIENTES " + Jugador.ANSI_RED + "INICIA UNA OLEADA" + Jugador.ANSI_RESET);
		suspenderEjecucion(1000);
	}

	/**
	 * Este metodo sirve para guardar el tablero, jugador, enemigo y enemigos a
	 * generar para que sean accesibles por el proyectil de la torre
	 * 
	 * 
	 * @param tablero         Objeto tablero el cual sirve para acceder a los
	 *                        metodos de la clase
	 * @param jugador         Objeto que sirve para acceder a los metodos de la
	 *                        clase
	 * @param enemigo         Array de objetos enemigo
	 * @param enemigosGenerar entero de enemigos a generar por oleada
	 */
	public void setTableroyJugador(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {
		this.tablero = tablero;
		this.jugador = jugador;
		this.enemigo = enemigo;
		this.enemigosGenerar = enemigosGenerar;

	}

	public String getNivel() {
		return nivel;
	}

	public void setNivel(String nivel) {
		this.nivel = nivel;
	}

	public String getPrecio() {
		return precio;
	}

	/**
	 * Este metodo sirve para poner el precio a las torres, el cual el precio
	 * recibido en entero se convertira en String, ya que en la torre de nivel 3 el
	 * precio es NIVEL MAXIMO ALCAZADO y no un numerico, entonces por eso usamos
	 * strings
	 * 
	 * @param precio un valor numerico entero
	 */
	public void setPrecio(int precio) {

		String intercambio = String.valueOf(precio);

		this.precio = intercambio;
	}

	public long getId() {
		return id;
	}

	public int getFila() {
		return fila;
	}

	public int getColumna() {
		return columna;
	}

	public boolean isDestruida() {
		return destruida;
	}

	public void setDestruida(boolean noDestruida) {
		this.destruida = noDestruida;
	}

	public static int getContador() {
		return contador;
	}

	public static void setContador(int contador) {
		Torre.contador = contador;
	}

	public boolean isPuedeDisparar() {
		return puedeDisparar;
	}

	public void setPuedeDisparar(boolean puedeDisparar) {
		this.puedeDisparar = puedeDisparar;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Metodo que sirve para parar la ejecucion del hilo durante el tiempo deseado
	 * 
	 * @param tiempo valor que el usuario desee introducir
	 */
	private static void suspenderEjecucion(int tiempo) {
		try {
			Thread.sleep(tiempo);
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}
	}

}
