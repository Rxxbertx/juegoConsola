package juego;

/**
 * Esta es la clase del proyectil que disparan las torres hacia los enemigos
 * 
 * @author roberto
 * @version 4.0
 * @since 0.9 Alpha
 *
 */
public class Proyectil extends Thread {

	private int columna;
	private int fila;

	private String proyectil;
	static final String PROYECTIL_NIVEL_1 = "-";
	static final String PROYECTIL_NIVEL_2 = "◉";
	static final String PROYECTIL_NIVEL_3 = "●";

	/**
	 * Constructor con parametros el cual asigna una serie de atributos y tambien
	 * dependiendo del nivel de la torre escogera un misil u otro, el cual
	 * atravesara mas de un enemigo dependiendo del nivel del misil
	 * 
	 * @param tablero         Objeto necesario para acceder a metodos de la clase
	 * @param columna2        Entero necesario para posicionar la columna del misil
	 *                        al igual que la columna de la torre
	 * @param fila2           Entero necesario para posiconar la fila del misi al
	 *                        igual que la fila de la torre
	 * @param nivel           String necesario para saber dependiendo del nivel de
	 *                        la torre que nivel de proyectil asignar
	 * @param jugador         Objeto necesario para acceder a metodos de la clase
	 * @param enemigo         Array de objetos necesario para pasarlo como argumento
	 *                        a otros metodos de esta clase
	 * @param enemigosGenerar entero con la cantidad de enemigos generados el cual
	 *                        sera de utilidad para otros metodos de esta clase
	 */
	Proyectil(Tablero tablero, int columna2, int fila2, String nivel, Jugador jugador, Enemigo[] enemigo,
			int enemigosGenerar) {

		this.columna = columna2;
		this.fila = fila2;

		switch (nivel) {

		case Torre.NIVEL1:

			this.proyectil = PROYECTIL_NIVEL_1;
			break;

		case Torre.NIVEL2:

			this.proyectil = PROYECTIL_NIVEL_2;
			break;

		case Torre.NIVEL3:

			this.proyectil = PROYECTIL_NIVEL_3;
			break;

		default:
			break;
		}

		avanza(tablero, jugador, enemigo, enemigosGenerar);

	}

	/**
	 * Este metodo permite al misil avazanr por el tablero y comprobar si ha chocado
	 * contra una torre o un enemigo
	 * 
	 * @param tablero         Objeto necesario para acceder a metodos de la clase
	 * @param jugador         Objeto necesario para acceder a metodos de la clase
	 * @param enemigo         Array de objetos necesario para pasarlo como argumento
	 *                        a otros metodos de esta clase
	 * @param enemigosGenerar entero con la cantidad de enemigos generados el cual
	 *                        sera de utilidad para otros metodos de esta clase
	 */
	private void avanza(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		if (tablero.isAlive()) {

			for (int i = columna + 1; i <= 49; i++) {
				setColumna(i);

				if (comprobarImpacto(tablero, jugador, enemigo, enemigosGenerar))
					break;

			}
		}

	}

	/**
	 * Este metodo sirve para comprobar si hemos impacto con una torre o con un
	 * enemigo, si hemos impactado con una torre no haremos nada, seguimos avanzado
	 * el misil, en cambio si hemos chocado contra una torre dependera del tipo de
	 * misil, un misil de nivel 3 puede acabar con 3 enemigos, el misil de nivel 2
	 * con 2 enemigos y el misil de nivel 1 solo con un enemigo. Si no choca con
	 * nada, entonces seguimos avanzado el misil por el tablero cada 100 ms
	 * 
	 * @param tablero         Objeto necesario para acceder a metodos de la clase
	 * @param jugador         Objeto necesario para acceder a metodos de la clase
	 * @param enemigo         Array de objetos necesario para pasarlo como argumento
	 *                        a otros metodos de esta clase
	 * @param enemigosGenerar entero con la cantidad de enemigos generados el cual
	 *                        sera de utilidad para otros metodos de esta clase
	 * @return devuelve un valor booleano, es decir si hemos chocado con una torre
	 *         devuelve false, entonces puede seguir avanzado, en cambio si hemos
	 *         chocado con un enemigo dependiendo de nuestro misil avanzamos o ya
	 *         paramos nuestro avance
	 */
	private boolean comprobarImpacto(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		if (impactoTorre(tablero)) {
			return false;

		} else if (impactoEnemigo(tablero, jugador, enemigo, enemigosGenerar)) {

			return true;

		} else {

			tablero.actualizaTablero(fila, columna, proyectil);

			suspenderEjecucion(150);

			tablero.actualizaTablero(fila, columna, " ");

			return false;

		}

	}

	/**
	 * Este metodo sirve para detectar la colision con una Torre, en el caso de
	 * impactar con una torre vamos a reescribirla en el tablero, primero mostramos
	 * nuestro misil y despues de 100ms volvemos a escribir la torre en ese lugar y
	 * simplemente seguimos avanzando el misil
	 * 
	 * @param tablero Objeto necesario para acceder a metodos de la clase
	 * @return si hemos chocado con una torre devuelve true, en cambio devuelve
	 *         false
	 */
	private boolean impactoTorre(Tablero tablero) {

		if (tablero.tablero[fila][columna].contains(Torre.NIVEL1)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL1);
			return true;

		} else if (tablero.tablero[fila][columna].contains(Torre.NIVEL2)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL2);
			return true;

		} else if (tablero.tablero[fila][columna].contains(Torre.NIVEL3)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL3);
			return true;
		}
		return false;
	}

	/**
	 * Este metodo sirve para detectar la colision con un enemigo. Para ello vamos a
	 * ir enemigo por enemigo comprobando si las coordenadas del proyectil coinciden
	 * con las del enemigo, para ello hacemos tripleComprobacion para que no se
	 * escape ningun enemigo
	 * 
	 * @see pararEnemigo
	 * 
	 * @param tablero         Objeto necesario para acceder a metodos de la clase
	 * @param jugador         Objeto necesario para acceder a metodos de la clase
	 * @param enemigo         Array de objetos necesario para pasarlo como argumento
	 *                        a otros metodos de esta clase
	 * @param enemigosGenerar entero con la cantidad de enemigos generados el cual
	 *                        nos sirve para saber cuantos enemigos tenemos que
	 *                        iterar
	 * 
	 * @return devuelve un valor booleano que sera el valor que retorne el metodo de
	 *         paraEnemigo
	 */
	private boolean impactoEnemigo(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {
		boolean impacto = false;

		for (int i = 0; i < enemigosGenerar; i++) {

			try {

				if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna + 1) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna + 1));

				} else if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna));

				} else if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna - 1) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna - 1));

				}

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

		return impacto;

	}

	/**
	 * En este metodo comprobamos si el enemigo que hemos chocado es uno que esta
	 * vivo y si es el caso de estar vivo procedemos a poner que esta aniquilado,
	 * ofrecemos puntos al jugador y dependiendo de nuestro proyectil seguiremos
	 * avanzado o no , un proyectil de nivel 1 desaparece, un proyectil de nivel 2
	 * sigue avanzando en forma de nivel 1, y el proyectil de nivel 3 pasara a nivel
	 * 2...
	 * 
	 * @param tablero Objeto tablero el cual usamos para llamar a sus metodos, en
	 *                este caso para actualizar el tablero
	 * @param jugador Objeto jugador el cual usamos para llamar a sus metodos, en
	 *                este caso para añadir puntos al usuario
	 * @param enemigo Array de objetos necesario para saber que enenmigo para y
	 *                hacer ciertas comprobaciones con el
	 * @param i       entero el cual determina a que enemigo del Array estamos
	 *                haciendo referencia
	 * @param columna Entero el cual sirve para actualizar la columna en la que
	 *                paramos el enemigo a vacio
	 * 
	 * @return Devuelve un valor booleano dependiendo de nuestro proyetil, si es de
	 *         nivel 1 true, si es de nivel 2 y 3 false, false es para que el
	 *         proyectil siga avanzando y no se pare (en metodos de esta misma clase
	 *         puedes observar este comportamiento)
	 */
	private boolean pararEnemigo(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int i, int columna) {
		boolean impacto = false;

		if (enemigo[i].isEnemigoVivo()) {

			enemigo[i].setEnemigoVivo(false);
			enemigo[i].stop();
			Enemigo.enemigosRestantes--;
			jugador.setDinero(1000);
			tablero.actualizaTablero(fila, columna, " ");

			switch (proyectil) {

			case PROYECTIL_NIVEL_1:

				impacto = true;
				break;

			case PROYECTIL_NIVEL_2:

				this.proyectil = PROYECTIL_NIVEL_1;

				impacto = false;
				break;

			case PROYECTIL_NIVEL_3:

				this.proyectil = PROYECTIL_NIVEL_2;

				impacto = false;
				break;

			default:

				impacto = true;
				break;

			}
		}
		return impacto;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	/**
	 * Metodo que sirve para parar la ejecucion del hilo durante el tiempo deseado
	 * 
	 * @param tiempo valor que el usuario desee introducir
	 */
	private static void suspenderEjecucion(int tiempo) {

		try {
			Thread.sleep(tiempo);
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}
	}
}
