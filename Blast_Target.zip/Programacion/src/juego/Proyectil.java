package juego;

/**
 * 
 * @author roberto
 *
 */
public class Proyectil extends Thread {

	private int columna;
	private int fila;

	private String proyectil;
	static final String proyectilNivel1 = "-";
	static final String proyectilNivel2 = "◉";
	static final String proyectilNivel3 = "●";

	/**
	 * 
	 * @param tablero
	 * @param columna2
	 * @param fila2
	 * @param nivel
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 */
	Proyectil(Tablero tablero, int columna2, int fila2, String nivel, Jugador jugador, Enemigo[] enemigo,
			int enemigosGenerar) {

		this.columna = columna2;
		this.fila = fila2;

		switch (nivel) {

		case Torre.NIVEL1:

			this.proyectil = proyectilNivel1;
			break;

		case Torre.NIVEL2:

			this.proyectil = proyectilNivel2;
			break;

		case Torre.NIVEL3:

			this.proyectil = proyectilNivel3;
			break;

		default:
			break;
		}

		avanza(tablero, jugador, enemigo, enemigosGenerar);

	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 */
	private void avanza(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		if (tablero.isAlive()) {

			for (int i = columna + 1; i <= 49; i++) {
				setColumna(i);

				if (comprobarImpacto(tablero, jugador, enemigo, enemigosGenerar))
					break;

			}
		}

	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 * @return
	 */
	private boolean comprobarImpacto(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		if (impactoTorre(tablero)) {
			return false;

		} else if (impactoEnemigo(tablero, jugador, enemigo, enemigosGenerar)) {

			return true;

		} else {

			tablero.actualizaTablero(fila, columna, proyectil);

			suspenderEjecucion(100);

			tablero.actualizaTablero(fila, columna, " ");

			return false;

		}

	}

	/**
	 * 
	 * @param tablero
	 * @return
	 */
	private boolean impactoTorre(Tablero tablero) {

		if (tablero.tablero[fila][columna].contains(Torre.NIVEL1)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL1);
			return true;

		} else if (tablero.tablero[fila][columna].contains(Torre.NIVEL2)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL2);
			return true;

		} else if (tablero.tablero[fila][columna].contains(Torre.NIVEL3)) {

			tablero.actualizaTablero(fila, columna, proyectil);
			suspenderEjecucion(120);
			tablero.actualizaTablero(fila, columna, Torre.NIVEL3);
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param tablero
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 * @return
	 */
	private boolean impactoEnemigo(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {
		boolean impacto = false;

		for (int i = 0; i < enemigosGenerar; i++) {

			try {

				if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna + 1) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna + 1));

				} else if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna));

				} else if (enemigo[i].getFila() == fila && enemigo[i].getColumna() == columna - 1) {

					impacto = pararEnemigo(tablero, jugador, enemigo, i, (columna - 1));

				}

			} catch (Exception e) {
				// TODO: handle exception
			}

		}

		return impacto;

	}

	/**
	 * @param tablero
	 * @param jugador
	 * @param enemigo
	 * @param i
	 * @param columna
	 */
	private boolean pararEnemigo(Tablero tablero, Jugador jugador, Enemigo[] enemigo, int i, int columna) {
		boolean impacto = false;

		if (enemigo[i].isEnemigoVivo()) {

			enemigo[i].setEnemigoVivo(false);
			enemigo[i].stop();
			Enemigo.enemigosRestantes--;
			jugador.setDinero(1000);
			tablero.actualizaTablero(fila, columna, " ");

			switch (proyectil) {

			case proyectilNivel1:

				impacto = true;
				break;

			case proyectilNivel2:

				this.proyectil = proyectilNivel1;

				impacto = false;
				break;

			case proyectilNivel3:

				this.proyectil = proyectilNivel2;

				impacto = false;
				break;

			default:

				impacto = true;
				break;

			}
		}
		return impacto;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	/**
	 * 
	 * @param tiempo
	 */
	private static void suspenderEjecucion(int tiempo) {

		try {
			Thread.sleep(tiempo);
		} catch (Exception e) {
			Thread.currentThread().interrupt();
		}
	}
}
