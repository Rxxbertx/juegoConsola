package juego;

/**
 * 
 * @author roberto
 *
 */
public class Oleada {

	public static int contadorOleadas = 0;
	static Thread enemigoStart;
	static Thread torreStart;
	static Runnable torres;
	static Runnable enemigos;

	/**
	 * 
	 * @param torre
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 * @return
	 */
	public static boolean oleadaInicio(Torre[] torre, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		Tablero tablero = new Tablero(5, 50, jugador, torre);

		tablero.start();

		iniciarEnemigos(torre, jugador, enemigo, enemigosGenerar, tablero);
		iniciarTorres(torre, jugador, tablero, enemigo, enemigosGenerar);

		while (tablero.isAlive()) {

		}

		return comprobarFin(jugador, enemigo, enemigosGenerar, torre);

	}

	/**
	 * 
	 * @param torre
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 * @param tablero
	 */

	private static void iniciarEnemigos(Torre[] torre, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar,
			Tablero tablero) {
		enemigos = new Runnable() {

			@Override
			public void run() {

				for (int i = 0; i < enemigosGenerar; i++) {
					enemigo[i] = new Enemigo(torre, tablero, jugador, enemigosGenerar);
					enemigo[i].start();
					try {
						Thread.sleep(500);
					} catch (Exception e) {
						Thread.currentThread().interrupt();
					}

				}

			}

		};

		enemigoStart = new Thread(enemigos);

		enemigoStart.start();
	}

	/**
	 * 
	 * @param torre
	 * @param jugador
	 * @param tablero
	 * @param enemigo
	 * @param enemigosGenerar
	 */
	private static void iniciarTorres(Torre[] torre, Jugador jugador, Tablero tablero, Enemigo[] enemigo,
			int enemigosGenerar) {

		torres = new Runnable() {

			@Override
			public void run() {
				for (int j = 0; j < Torre.contador; j++) {
					if (!torre[j].isDestruida()) {
						torre[j].setTableroyJugador(tablero, jugador, enemigo, enemigosGenerar);

						try {
							torre[j].start();
						} catch (Exception e) {
							torre[j].resume();
						}

					}

				}

			}
		};

		torreStart = new Thread(torres);
		torreStart.start();
	}

	/**
	 * 
	 * @param jugador
	 * @param enemigo
	 * @param enemigosGenerar
	 * @param torre
	 * @return
	 */
	private static boolean comprobarFin(Jugador jugador, Enemigo[] enemigo, int enemigosGenerar, Torre[] torre) {

		if (jugador.getVidas() == 0 || Torre.torresVivas == 0) {

			for (int i = 0; i < enemigosGenerar; i++) {

				try {
					enemigo[i].interrupt();
				} catch (Exception e) {

				}

			}
			for (int i = 0; i < Torre.contador; i++) {

				try {
					torre[i].interrupt();
				} catch (Exception e) {

				}

			}
			jugador.setVidas(3);
			return false;
		}
		if (Enemigo.enemigosRestantes == 0) {

			for (int i = 0; i < enemigosGenerar; i++) {

				try {
					enemigo[i].interrupt();
				} catch (Exception e) {

				}

			}

			jugador.setVidas(3);
			return true;
		}
		return false;
	}

}
