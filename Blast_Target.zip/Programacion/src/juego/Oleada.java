package juego;

/**
 * En esta clase se ejecutaran las entidades necesarias para iniciar la oleada,
 * hilos, objetos...
 * 
 * @author roberto
 * @version 0.5
 * @since 0.8 Alpha
 */
public class Oleada {

	public static int contadorOleadas = 0;
	static Thread enemigoStart;
	static Thread torreStart;
	static Runnable torres;
	static Runnable enemigos;

	/**
	 * Este metodo genera un nuevo tablero, inicia los enemigos y tambien inicia las
	 * torres. Todos estos objetos con sus respectivos hilos y ejecucciones
	 * individuales
	 * 
	 * @param torre           Array de objetos necesario para metodos de esta misma
	 *                        clasae
	 * @param jugador         Objeto necesario para metodos de esta misma clase
	 * @param enemigo         Objeto necesario para metodos de esta misma clase
	 * @param enemigosGenerar entero necesario para saber cuantos enemigos ejecutar
	 *                        y parar.
	 * @return un valor booleano, si es true en la clase de ejecuccion se incrementa
	 *         la oleada y los enemigos, y si es false no incrementaran los enemigos
	 *         ni la oleada
	 */
	public static boolean oleadaInicio(Torre[] torre, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar) {

		Tablero tablero = new Tablero(5, 50, jugador, torre);

		tablero.start();

		iniciarEnemigos(torre, jugador, enemigo, enemigosGenerar, tablero);
		iniciarTorres(torre, jugador, tablero, enemigo, enemigosGenerar);

		while (tablero.isAlive()) {

		}

		return comprobarFin(jugador, enemigo, enemigosGenerar, torre);

	}

	/**
	 * Este metodo tiene un Runnable de enemigos el cual dentro de su codigo esta la
	 * ejecuccion de cada enemigo, con un retraso de 500 ms entre cada enemigo,
	 * despues de eso se llama al hilo enemigoStart para ejecutar el Runnable y dar
	 * comienzo a la ejecuccion del bloque de codigo
	 * 
	 * @param torre           Array de objetos necesario para metodos de esta misma
	 *                        clasae
	 * @param jugador         Objeto necesario para metodos de esta misma clase
	 * @param enemigo         Objeto necesario para metodos de esta misma clase
	 * @param enemigosGenerar entero necesario para saber cuantos enemigos ejecutar
	 *                        y parar.
	 * @param tablero         Objeto necesario para poder posicionar la entidad y
	 *                        actualizar el tablero con ella.
	 */

	private static void iniciarEnemigos(Torre[] torre, Jugador jugador, Enemigo[] enemigo, int enemigosGenerar,
			Tablero tablero) {
		enemigos = new Runnable() {

			@Override
			public void run() {

				for (int i = 0; i < enemigosGenerar; i++) {
					enemigo[i] = new Enemigo(torre, tablero, jugador);
					enemigo[i].start();
					try {
						Thread.sleep(500);
					} catch (Exception e) {
						Thread.currentThread().interrupt();
					}

				}

			}

		};

		enemigoStart = new Thread(enemigos);

		enemigoStart.start();
	}

	/**
	 * Este metodo tiene un Runnable el cual dentro de su codigo esta la ejecuccion
	 * de cada torre ,se llama al hilo torreStart para ejecutar el Runnable y dar
	 * comienzo a la ejecuccion del bloque de codigo
	 * 
	 * @param torre           Array de objetos necesario para metodos de esta misma
	 *                        clasae
	 * @param jugador         Objeto necesario para metodos de esta misma clase
	 * @param enemigo         Objeto necesario para metodos de esta misma clase
	 * @param enemigosGenerar entero necesario para saber cuantos enemigos ejecutar
	 *                        y parar.
	 * @param tablero         Objeto necesario para poder posicionar la entidad y
	 *                        actualizar el tablero con ella.
	 */
	private static void iniciarTorres(Torre[] torre, Jugador jugador, Tablero tablero, Enemigo[] enemigo,
			int enemigosGenerar) {

		torres = new Runnable() {

			@Override
			public void run() {
				for (int j = 0; j < Torre.contador; j++) {

					/**
					 * Solamente las torres no destruidas se inician o se resumen si ya fueron
					 * iniciadas en oleadas anteriores
					 */

					if (!torre[j].isDestruida()) {
						torre[j].setTableroyJugador(tablero, jugador, enemigo, enemigosGenerar);

						try {
							torre[j].start();
						} catch (Exception e) {
							torre[j].resume();
						}

					}

				}

			}
		};

		torreStart = new Thread(torres);
		torreStart.start();
	}

	/**
	 * Este metodo comprueba de que modo a finalizado la oleada, si el jugador con 0
	 * vidas o 0 torres o bien a conseguido matar a todos los enemigos. Despues se
	 * paran todos los hilos
	 * 
	 * @param torre           Array de objetos necesario para metodos de esta misma
	 *                        clasae
	 * @param jugador         Objeto necesario para metodos de esta misma clase
	 * @param enemigo         Objeto necesario para metodos de esta misma clase
	 * @param enemigosGenerar entero necesario para saber cuantos enemigos parar.
	 * @return un valor booleano
	 */
	private static boolean comprobarFin(Jugador jugador, Enemigo[] enemigo, int enemigosGenerar, Torre[] torre) {

		if (jugador.getVidas() <= 0 || Torre.torresVivas == 0) {

			finalizarEntidades(enemigo, enemigosGenerar, torre);
			jugador.setVidas(3);
			return false;
		}
		if (Enemigo.enemigosRestantes == 0) {

			finalizarEntidades(enemigo, enemigosGenerar, torre);
			jugador.setVidas(3);
			return true;
		}
		return false;
	}

	/**
	 * Este metodo va parando una a una los hilos tanto las torres como los enemigos
	 * generados.
	 * 
	 * @param enemigo         Es el array de objetos para ir enemigo por enemigo
	 * @param enemigosGenerar Son los enemigos que hemos generado, necesarios para
	 *                        realizar la iteracion sobre el Array de objetos
	 *                        Enemigo
	 * @param torre           Array de objetos para finalizar las torres existentes
	 */
	private static void finalizarEntidades(Enemigo[] enemigo, int enemigosGenerar, Torre[] torre) {
		for (int i = 0; i < enemigosGenerar; i++) {

			try {
				enemigo[i].interrupt();
			} catch (Exception e) {

			}

		}
		for (int i = 0; i < Torre.contador; i++) {

			try {
				torre[i].interrupt();
			} catch (Exception e) {

			}

		}
	}

}
