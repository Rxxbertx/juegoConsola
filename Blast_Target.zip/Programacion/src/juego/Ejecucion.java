package juego;

import java.util.Scanner;

/**
 * <h1>Blast Target</h1> es un juego realizado por <b>Roberto</b> y aportaciones de <b>Alexis</b>
 * @author Roberto J.T
 *
 */

public class Ejecucion {
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int enemigosGenerar = 20;
		final int FILA = 5;
		final int COLUMNA = 50;
		boolean salir = false;

		Torre[] torre = new Torre[25];
		Jugador player = new Jugador();
		Tablero t1 = new Tablero(FILA, COLUMNA, player, torre);

		bienvenida();

		while (!salir) {

			Jugador.stats(player);
			t1.imprimeTablero(torre);

			int resp = menu(sc);

			switch (resp) {
			case 1:

				Torre.comprarTorre(torre, player, t1);

				break;
			case 2:

				Torre.seleccionarTorreActualizar(torre, t1, player, sc);

				break;

			case 3:

				enemigosGenerar = iniciarOleada(enemigosGenerar, torre, player, t1);

				break;

			default:
				salir = true;
				break;
			}
		}

	}
/**
 * 
 */
	private static void bienvenida() {
		String bichos = "\n\n\n\n\n\n\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n"
				+ "░░░░░▄▄████▄▄░░░░░░░░░░░░░░░░░░░░░░░░░░▄▄████▄▄░░░░░\n"
				+ "░░░▄██████████▄░░░░░░█▀███████▀█░░░░░░██████████░░░░\n"
				+ "░▄██▄██▄██▄██▄██▄░░░░░▄█▀███▀█▄░░░░░░░██▄▄██▄▄██░░░░\n"
				+ "░░░▀█▀░░▀▀░░▀█▀░░░░░░█░█▀▀▀▀▀█░█░░░░░░░▄▀▄▀▀▄▀▄░░░░░\n"
				+ "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▀░░░░░░░░▀░░░░\n"
				+ "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n";

		for (int i = 0; i < bichos.length(); i++) {
			try {
				Thread.sleep(10);
				System.out.print(Jugador.ANSI_BLACK_BACKGROUND+Jugador.colorAleatorio()+bichos.charAt(i)+Jugador.ANSI_RESET);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				
			}
			
		}
	}

	/**
	 * 
	 * @param enemigosGenerar
	 * @param torre
	 * @param player
	 * @param t1
	 * @return
	 */
	private static int iniciarOleada(int enemigosGenerar, Torre[] torre, Jugador player, Tablero t1) {
		Enemigo[] enemigo = new Enemigo[enemigosGenerar];
		Enemigo.enemigosRestantes = enemigosGenerar;

		if (Oleada.oleadaInicio(torre, player, enemigo, enemigosGenerar)) {

			enemigosGenerar += 2;
			Oleada.contadorOleadas++;
			Jugador.stats(player);
			t1.imprimeTablero(torre);

		}
		Jugador.stats(player);
		t1.imprimeTablero(torre);
		return enemigosGenerar;
	}

	/**
	 * 
	 * @param sc
	 * @return
	 */
	private static int menu(Scanner sc) {

		System.err.print("COMPRAR TORRE (1)   ");
		System.err.print("ACTUALIZAR TORRE (2)   ");
		System.err.print("INICIAR OLEADA (3)\n");
		return sc.nextInt();

	}

}
