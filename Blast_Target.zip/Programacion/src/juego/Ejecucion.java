package juego;

import java.util.Scanner;

/**
 * <h1>Blast Target</h1> es un juego realizado por <b>Roberto</b> y aportaciones
 * de <b>Alexis</b> consiste en Comprar y mejorar tus propias torres mientras
 * vas avanzando en oleadas y nuevos enemigos intentaran acabar contigo
 * 
 * @author Roberto J.T
 * @version 1.0 Alpha
 */

public class Ejecucion {
	/**
	 * Se declaran ciertas variables que se pasan como argumento para ciertos
	 * metodos y disponemos de 3 opciones a realizar por el usuario
	 * 
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int enemigosGenerar = 20;
		final int FILA = 5;
		final int COLUMNA = 50;
		boolean salir = false;

		Torre[] torre = new Torre[25];
		Jugador player = new Jugador();
		Tablero t1 = new Tablero(FILA, COLUMNA, player, torre);

		bienvenida();

		while (!salir) {

			Jugador.stats(player);
			t1.imprimeTablero(torre);

			int resp = menu(sc);

			switch (resp) {
			case 1:

				//mirar clase Torre
				
				Torre.comprarTorre(torre, player, t1);

				break;
			case 2:

				//mirar clase Torre
				
				Torre.seleccionarTorreActualizar(torre, t1, player, sc);

				break;

			case 3:

				enemigosGenerar = iniciarOleada(enemigosGenerar, torre, player, t1);
				menu(sc);
				break;

			default:
				salir = true;
				break;
			}
		}

	}

	/**
	 * Este metodo es la pantalla de bienvendia en la cual se mostrara por pantalla
	 * este dibujo y sera pintado cada caracter de manera aleatoria entre amarillo y
	 * verde sobre un fondo negro
	 */
	private static void bienvenida() {
		String bichos = "\n\n\n\n\n\n\n░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n"
				+ "░░░░░▄▄████▄▄░░░░░░░░░░░░░░░░░░░░░░░░░░▄▄████▄▄░░░░░\n"
				+ "░░░▄██████████▄░░░░░░█▀███████▀█░░░░░░██████████░░░░\n"
				+ "░▄██▄██▄██▄██▄██▄░░░░░▄█▀███▀█▄░░░░░░░██▄▄██▄▄██░░░░\n"
				+ "░░░▀█▀░░▀▀░░▀█▀░░░░░░█░█▀▀▀▀▀█░█░░░░░░░▄▀▄▀▀▄▀▄░░░░░\n"
				+ "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░▀░░░░░░░░▀░░░░\n"
				+ "░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░\n";

		for (int i = 0; i < bichos.length(); i++) {
			try {
				Thread.sleep(10);
				System.out.print(Jugador.ANSI_BLACK_BACKGROUND + Jugador.colorAleatorio() + bichos.charAt(i)
						+ Jugador.ANSI_RESET);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block

			}

		}
	}

	/**
	 * Este metodo es el cual dara lugar a la ejecuccion de las oleadas y puesta en
	 * marcha de las torres y enemigos, cada vez que inicie una oleada, creamos un
	 * array de objetos con una cantidad variable de objetos a guardar (enemigos a
	 * generar)
	 * 
	 * @param enemigosGenerar los enemigos a generar
	 * @param torre           el array de objetos torre
	 * @param player          el jugador
	 * @param t1              el tablero
	 * @return devuelve los enemigosAGenerar para la proxima oleada, si es true los
	 *         incrementa y si es false no incrementara.
	 */
	private static int iniciarOleada(int enemigosGenerar, Torre[] torre, Jugador player, Tablero t1) {
		Enemigo[] enemigo = new Enemigo[enemigosGenerar];
		Enemigo.enemigosRestantes = enemigosGenerar;

		if (Oleada.oleadaInicio(torre, player, enemigo, enemigosGenerar)) {

			enemigosGenerar += 2;
			Oleada.contadorOleadas++;
			Jugador.stats(player);
			t1.imprimeTablero(torre);

		}
		Jugador.stats(player);
		t1.imprimeTablero(torre);
		return enemigosGenerar;
	}

	/**
	 * Se muestran las distinta opciones que puede realizar el usuario, estando a la
	 * espera de su respuesta
	 * 
	 * @param sc objeto de tipo scanner para esperar la entrada del usuario.
	 * @return devolvemos la respuesta
	 */
	private static int menu(Scanner sc) {

		System.err.print("COMPRAR TORRE (1)   ");
		System.err.print("ACTUALIZAR TORRE (2)   ");
		System.err.print("INICIAR OLEADA (3)\n");
		return sc.nextInt();

	}

}
